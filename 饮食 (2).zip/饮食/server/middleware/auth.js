const jwt = require('jsonwebtoken');
require('dotenv').config();

const auth = (req, res, next) => {
  // console.log(req.header('Authorization'));
  // const token = req.header('Authorization').replace('Bearer ', '');
  console.log(req.headers);
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1]; // 提取Bearer后的Token

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

module.exports = auth;