const express = require('express');
const cors = require('cors');
const db = require('./db');
const postsRouter = require('./routes/posts');
const usersRouter = require('./routes/users');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use('/api/posts', postsRouter);
app.use('/api/users', usersRouter);

app.get("/test", async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM users WHERE username = ?', ['1']);
    console.log(rows);
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});