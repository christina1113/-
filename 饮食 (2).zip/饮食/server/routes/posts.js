const express = require('express');
const router = express.Router();
const db = require('../db');
const auth = require('../middleware/auth');

// 创建帖子
router.post('/create', auth, async (req, res) => {
  try {
    const { content, images, tags } = req.body;
    const { userId } = req.user;

    const [result] = await db.query(
      'INSERT INTO posts (user_id, content, images, tags, like_count, comment_count, create_time) VALUES (?, ?, ?, ?, 0, 0, NOW())',
      [userId, content, images, tags]
    );

    res.status(201).json({ id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;