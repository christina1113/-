Page({
  data: {
    mealTypes: ['早餐', '午餐', '晚餐', '加餐'],
    mealType: '早餐',
    calorieRanges: ['0-300', '300-500', '500-800', '800+'],
    calorieRange: '300-500',
    recommendations: [],
    allRecipes: [
      // 早餐食谱
      { id: 1, name: '全麦三明治', mealType: '早餐', calories: 280, image: '/images/recipes/1.jpeg', matchRate: 0,
        ingredients: "全麦面包2片, 鸡蛋1个, 生菜2片, 番茄3片, 低脂奶酪1片",
        steps: "1. 煎蛋 2. 面包烤至微黄 3. 依次放生菜、番茄、鸡蛋、奶酪 4. 对角切开" },
      { id: 2, name: '燕麦牛奶粥', mealType: '早餐', calories: 250, image: '/images/recipes/2.jpg', matchRate: 0,
        ingredients: "燕麦片50g, 低脂牛奶200ml, 蓝莓20g, 坚果10g",
        steps: "1. 燕麦牛奶煮3分钟 2. 加入蓝莓和坚果" },
      
      // 午餐食谱
      { id: 3, name: '香煎三文鱼饭', mealType: '午餐', calories: 450, image: '/images/recipes/3.jpg', matchRate: 0,
        ingredients: "三文鱼150g, 糙米100g, 西兰花100g, 柠檬1/4个",
        steps: "1. 三文鱼用盐和黑胡椒腌制 2. 煎至两面金黄 3. 搭配煮熟的糙米和焯水西兰花" },
      { id: 4, name: '牛肉意面', mealType: '午餐', calories: 520, image: '/images/recipes/4.jpeg', matchRate: 0,
        ingredients: "全麦意面80g, 牛肉末100g, 番茄1个, 洋葱1/4个",
        steps: "1. 煮意面 2. 炒香洋葱 3. 加入牛肉和番茄炒熟 4. 混合意面" },
      
      // 晚餐食谱
      { id: 5, name: '清蒸鲈鱼', mealType: '晚餐', calories: 350, image: '/images/recipes/5.jpg', matchRate: 0,
        ingredients: "鲈鱼1条(约500g), 姜片5片, 葱2根",
        steps: "1. 鱼身划刀 2. 放姜片葱段 3. 蒸8分钟 4. 淋热油和酱油" },
      { id: 6, name: '鸡肉沙拉', mealType: '晚餐', calories: 380, image: '/images/recipes/6.jpg', matchRate: 0,
        ingredients: "鸡胸肉150g, 混合蔬菜200g, 小番茄10个, 橄榄油5ml",
        steps: "1. 鸡胸肉煮熟撕条 2. 蔬菜洗净 3. 混合所有食材 4. 加橄榄油和醋" },
      
      // 加餐食谱
      { id: 7, name: '希腊酸奶杯', mealType: '加餐', calories: 200, image: '/images/recipes/7.jpg', matchRate: 0,
        ingredients: "希腊酸奶150g, 奇异果1个, 格兰诺拉麦片20g",
        steps: "1. 奇异果切丁 2. 分层放入酸奶、水果和麦片" },
      { id: 8, name: '坚果能量棒', mealType: '加餐', calories: 180, image: '/images/recipes/8.jpeg', matchRate: 0,
        ingredients: "混合坚果50g, 燕麦片30g, 蜂蜜10g",
        steps: "1. 所有材料混合 2. 压制成型 3. 冷藏1小时" },
      
      // 其他食谱
      { id: 9, name: '蔬菜煎饼', mealType: '早餐', calories: 320, image: '/images/recipes/9.jpg', matchRate: 0,
        ingredients: "全麦面粉50g, 鸡蛋1个, 胡萝卜1/4根, 西葫芦1/4根",
        steps: "1. 蔬菜切丝 2. 混合所有材料 3. 小火煎至两面金黄" },
      { id: 10, name: '虾仁炒饭', mealType: '午餐', calories: 480, image: '/images/recipes/10.jpg', matchRate: 0,
        ingredients: "虾仁100g, 糙米饭150g, 鸡蛋1个, 豌豆30g",
        steps: "1. 炒熟鸡蛋 2. 炒虾仁 3. 加入米饭和豌豆翻炒" }
    ]
  },

  onLoad() {
    this.loadRecommendations();
  },

  // 更新推荐算法
  loadRecommendations() {
    const { mealType, calorieRange, allRecipes } = this.data;
    const [minCal, maxCal] = calorieRange.split('-').map(Number);
    
    let filtered = allRecipes.filter(item => {
      // 匹配餐别
      if (item.mealType !== mealType) return false;
      
      // 匹配热量范围
      if (calorieRange === '800+') {
        return item.calories >= 800;
      }
      return item.calories >= minCal && item.calories <= (maxCal || Infinity);
    });
    
    // 计算匹配度 (示例算法)
filtered = filtered.map(item => ({
  ...item,
  matchRate: Math.min(
    100,
    Math.round(100 - Math.abs(item.calories - (minCal + (maxCal || 800) / 2) / 10))
  )
}));
    
    // 按匹配度排序
    filtered.sort((a, b) => b.matchRate - a.matchRate);
    
    this.setData({ recommendations: filtered });
  },

  // 保持其他方法不变
  changeMealType(e) {
    this.setData({ 
      mealType: this.data.mealTypes[e.detail.value] 
    }, this.loadRecommendations);
  },

  changeCalorieRange(e) {
    this.setData({ 
      calorieRange: this.data.calorieRanges[e.detail.value] 
    }, this.loadRecommendations);
  },

  viewDetail(e) {
    const id = e.currentTarget.dataset.id;
    const recipe = this.data.allRecipes.find(item => item.id === id);
    wx.navigateTo({
      url: `/pages/recipe-detail/index?id=${id}`,
    });
  }
});