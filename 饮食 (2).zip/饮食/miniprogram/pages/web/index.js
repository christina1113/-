import { getUserInfo, getHealthData } from '../../services/user';
import { getAchievements } from '../../services/achievement';

Page({
  data: {
    isLogin: false,
    userInfo: {},
    healthData: { height: 170, weight: 65, targetWeight: 60 },
    favorites: [
      {
        id: 1,
        image: '/images/recipe1.jpg',
        title: 'Apple Pie',
        calories: 320
      },
    ],
    achievements: [],
    personalInfo: '这里是你的个人简介，可以编辑和更新。',
    followersCount: 0,
    followingCount: 0
  },
  viewRecipe(event) {
    const recipe = event.detail;
    wx.navigateTo({
      url: `/pages/recipe-detail/recipe-detail?id=${recipe.id}`
    });
  },
  viewAllFavorites() {
    wx.navigateTo({
      url: '/pages/favorites/favorites'
    });
  },
  onLoad() {
    this.loadMockData(); // 先用模拟数据测试
  },

  // 模拟数据加载（完成后替换为真实接口）
  loadMockData() {
    this.setData({
      favorites: [
        { id: 1, title: '低卡鸡胸肉', image: '/images/default-goods-image.png', calories: 320 }
      ],
      achievements: [
        { id: 1, name: '连续登录', icon: '/images/icons/list-init.png', unlocked: true }
      ],
      personalInfo: '这里是你的个人简介，可以编辑和更新。',
      followersCount: 150,
      followingCount: 50
    });
  },

  handleWechatLogin() {
    wx.login({
      success: () => {
        this.setData({ isLogin: true });
        wx.showToast({ title: '登录成功' });
      }
    });
  }
});