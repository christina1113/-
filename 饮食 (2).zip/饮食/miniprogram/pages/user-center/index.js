// 导入所需的服务
import {
  getUserInfo,
  getHealthData
} from '../../services/user';
import {
  getAchievements
} from '../../services/achievement';

// import { getFavorites } from '../../services/favorite';
const db = wx.cloud.database().collection('users');
let app = getApp()
Page({
  data: {
    isLogin: false,
    userInfo: {},
    healthData: {
      height: 170,
      weight: 65,
      targetWeight: 60
    },
    favorites: [],
    achievements: [],
    personalInfo: '这里是你的个人简介，可以编辑和更新。',
    followersCount: 150,
    followingCount: 50,
    favoritesCount: 5, // 初始化收藏数量
  },
  viewRecipe(event) {
    const recipe = event.detail;
    wx.navigateTo({
      url: `/pages/recipe-detail/recipe-detail?id=${recipe.id}`
    });
  },

  onShow() {
    const favorites = wx.getStorageSync('favorites') || []
    this.data.favoritesCount = favorites.length
    this.setData({
      favoritesCount: this.data.favoritesCount,
      isLogin: app.globalData.isLogin,
      userInfo: wx.getStorageSync('userInfo')
    })
  },

  viewAllFavorites() {
    wx.navigateTo({
      url: '/pages/favorites/favorites'
    });
  },
  onLoad() {
    this.loadMockData(); // 先用模拟数据测试
  },

  // 模拟数据加载（完成后替换为真实接口）
  loadMockData() {
    this.setData({
      userInfo: {
        nickName: 'Chris',
        email: 'Chris2025@qq.com',
        avatarUrl: '/images/avatar.png'
      },
      favorites: [{
        id: 1,
        title: '低卡鸡胸肉',
        image: '/images/jxr.jpg',
        calories: 320
      }],
      achievements: [{
        id: 1,
        name: '连续登录',
        icon: '/images/init.jpg',
        unlocked: true
      }],
      personalInfo: '这里是你的个人简介，可以编辑和更新。',
      followersCount: 150,
      followingCount: 50
    });
  },

  async getUserProfile(e) {
    try {
      await wx.getUserProfile({
        desc: "授权获取你的微信头像和昵称", // 授权弹窗描述
        success: async (res) => {
          // 1. 获取临时登录凭证 code
          const {
            code
          } = await wx.login();
          if (!code) throw new Error("登录凭证获取失败");

          // 2. 调用云函数进行登录验证
          const ress = await wx.cloud.callFunction({
            name: "login",
            data: {
              code,
            }
          });
          const userInfo = res.userInfo
          console.log(ress, userInfo, '获取openid成功');

          // 3. 处理登录结果
          if (ress.errMsg === "cloud.callFunction:ok") {
            const {
              openid
            } = ress.result;

            let {
              data
            } = await db.where({
              _openid: openid
            }).get()
            console.log(data, '擦洗');
            // 保存用户数据
            if (!data.length) {
              const result = await db.add({
                data: {
                  openid,
                  ...userInfo
                }
              })
            }

            // 存储用户登录状态（本地缓存或全局变量）
            wx.setStorageSync("userInfo", userInfo);
            wx.setStorageSync("openid", openid);
            app.globalData.openid = openid
            wx.showToast({
              title: "登录成功",
              icon: "success"
            });
            this.data.isLogin = true
            this.data.userInfo = userInfo
            this.setData({
              isLogin: this.data.isLogin,
              userInfo: this.data.userInfo
            });
          } else {
            wx.showToast({
              title: ress.result.message,
              icon: "none"
            });
          }
        }
      });
    } catch (error) {
      console.error("登录流程错误：", error);
      wx.showToast({
        title: "登录失败，请重试",
        icon: "none"
      });
    }
  }
});