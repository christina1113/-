// pages/index.js
const db = wx.cloud.database().collection('posts');
const app = getApp()
Page({
  data: {
    posts: [], // 初始化帖子数组
    leftPosts: [], // 左栏帖子
    rightPosts: [], // 右栏,
    active: 1, //1为发现 2为我的
  },

  onLoad: function () {
    this.loadPosts(); // 页面加载时调用 loadPosts 方法加载帖子数据
  },
  loadPosts: function (type) {
    let search = {}
    if (type) {
      search = {
        openid: app.globalData.openid
      }
    }

    wx.cloud.callFunction({
      name: 'getPosts',
      data: {
        userId: app.globalData.openid,
        ...search
      },
      success: res => {
        console.log(res);
        const posts = res.result.data.data;
        const leftPosts = posts.filter((_, index) => index % 2 === 0);
        const rightPosts = posts.filter((_, index) => index % 2 !== 0);
        this.setData({
          posts,
          leftPosts,
          rightPosts
        });
      },
      fail: err => {
        console.error('帖子数据加载失败', err);
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      }
    })

    return

    db.where({
      ...search
    }).get({
      success: res => {
        console.log(res);
        const posts = res.data;
        const leftPosts = posts.filter((_, index) => index % 2 === 0);
        const rightPosts = posts.filter((_, index) => index % 2 !== 0);
        this.setData({
          posts,
          leftPosts,
          rightPosts
        });
      },
      fail: err => {
        console.error('帖子数据加载失败', err);
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      }
    })
  },



  viewDetail: function (event) {
    const postId = event.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/post-detail/index?id=${postId}`
    });
  },

  createPost: function () {
    wx.navigateTo({
      url: '/pages/create-post/index' // 跳转到发帖页面
    });
  },

  changeActive: function (e) {
    let {
      currentTarget: {
        dataset: {
          active
        }
      }
    } = e
    this.data.active = active
    this.setData({
      active: this.data.active
    })
    if (active == 2) {
      this.loadPosts('me')
    } else {
      this.loadPosts()
    }
  },

  addcollect(e) {
    let {
      currentTarget: {
        dataset: {
          postid,collect
        }
      }
    } = e
    console.log(postid,collect);

    const userId = app.globalData.openid
    let that = this
    wx.cloud.callFunction({
      name: 'collections',
      data: {
        userId,
        postId: postid
      },
      success: res => {
        if (that.data.active == 2) {
          that.loadPosts('me')
        } else {
          that.loadPosts()
        }
        wx.showToast({
          title: res.result.message,
          icon: 'none'
        })
      },
      fail: err => {
        console.error(err)
        wx.showToast({
          title: '收藏失败',
          icon: 'none'
        })
      }
    })
  }
});