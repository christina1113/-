import { getFeaturedRecipes } from '../../services/recipe';

Page({
  data: {
    featuredRecipes: []
  },
  onLoad() {
    this.loadFeaturedRecipes();
  },
  loadFeaturedRecipes() {
    // 模拟数据加载
    this.setData({
       featuredRecipes: [
         { id: 1, title: 'Apple Pie', image: '/images/recipe1.jpg', calories: 320 },
         { id: 2, title: 'Banana Smoothie', image: '/images/recipe2.jpg', calories: 250 },
         { id: 3, title: 'Vegetable Salad', image: '/images/recipe3.jpg', calories: 150 }
       ]
     });
  },
    // 新增的健康饮食小科普跳转方法
    navigateToHealthTips() {
      wx.navigateTo({
        url: '/pages/kepu/kepu'
      });
    },
  viewRecipeDetail(event) {
    
    wx.navigateTo({
     url: `/pages/kepu/kepu`
   });
  },
  navigateToCalorieCalculator() {
    wx.navigateTo({
     url: '/pages/calorie-calculator/calorie-calculator'
   });
  },
  navigateToFavorites() {
    wx.navigateTo({
     url: '/pages/favorites/favorites'
   });
  },
  navigateToRecommendations() {
    wx.navigateTo({
     url: '/pages/recommendations/index'
   });
  }
});