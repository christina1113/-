Page({
  data: {
    favorites: [
      {
        id: 1,
        name: '番茄炒蛋',
        image: '/images/tomato.jpg',
        calories: 300,
        ingredients: '番茄2个，鸡蛋3个，盐，糖，油',
        steps: '1. 番茄切块，鸡蛋打散。\n2. 热锅加油，倒入鸡蛋液，炒至凝固。\n3. 加入番茄块，加盐和糖调味，炒至番茄出汁。',
        collectTime: '2024-04-01'
      },
      {
        id: 2,
        name: '宫保鸡丁',
        image: '/images/kungpao.jpg',
        calories: 400,
        ingredients: '鸡胸肉200g，花生50g，干辣椒，花椒，葱，姜，蒜，酱油，醋，糖，盐，淀粉',
        steps: '1. 鸡胸肉切丁，用酱油、淀粉腌制。\n2. 热锅加油，炒香花椒和干辣椒。\n3. 加入鸡丁，炒至变色。\n4. 加入葱姜蒜，花生，酱油、醋、糖、盐调味，翻炒均匀。',
        collectTime: '2024-04-02'
      },
      {
        id: 3,
        name: '清蒸鲈鱼',
        image: '/images/steamed.jpg',
        calories: 250,
        ingredients: '鲈鱼1条，姜，葱，料酒，盐，酱油',
        steps: '1. 鲈鱼洗净，用料酒、盐腌制。\n2. 鱼身放姜片，葱段。\n3. 上锅蒸10分钟。\n4. 淋上热油和酱油。',
        collectTime: '2024-04-03'
      },
      {
        id: 4,
        name: '蒜蓉西兰花',
        image: '/images/broccoli.jpg',
        calories: 200,
        ingredients: '西兰花1颗，大蒜5瓣，盐，油',
        steps: '1. 西兰花切小朵，焯水。\n2. 热锅加油，炒香蒜末。\n3. 加入西兰花，加盐调味，翻炒均匀。',
        collectTime: '2024-04-04'
      },
      {
        id: 5,
        name: '土豆烧牛肉',
        image: '/images/beef.jpg',
        calories: 500,
        ingredients: '牛肉300g，土豆2个，胡萝卜1根，洋葱半个，酱油，盐，糖，料酒，姜，蒜',
        steps: '1. 牛肉切块，焯水去血沫。\n2. 热锅加油，炒香姜蒜。\n3. 加入牛肉块，炒至变色。\n4. 加入土豆块、胡萝卜块、洋葱块，酱油、盐、糖、料酒调味，加水炖煮。',
        collectTime: '2024-04-05'
      }
    ]
  },

  onShow() {
    this.loadFavorites();
  },

  loadFavorites() {
    const favorites = wx.getStorageSync('favorites') || this.data.favorites;

    console.log(favorites);

   
      wx.setStorageSync('favorites',this.data.favorites)
    

    console.log('Favorites loaded:', favorites); 
    this.setData({ favorites }, () => {
      console.log('Favorites data set:', this.data.favorites); // 添加日志输出
    });
  },

  removeFavorite(e) {
    const id = e.currentTarget.dataset.id;
    const newFavorites = this.data.favorites.filter(item => item.id !== id);
    wx.setStorageSync('favorites', newFavorites);
    this.setData({ favorites: newFavorites });
    wx.showToast({ title: '已移除' });
  }
});