Page({
  data: {
    tips: [{
        title: '均衡饮食',
        content: '确保摄入足够的蛋白质、碳水化合物、脂肪、维生素和矿物质。'
      },
      {
        title: '控制盐分',
        content: '减少食盐摄入，预防高血压。'
      },
      {
        title: '适量饮水',
        content: '每天至少喝八杯水，保持身体水分平衡。'
      },
      {
        title: '定期运动',
        content: '每周至少进行150分钟的中等强度运动。'
      },
      {
        title: '避免加工食品',
        content: '减少加工食品和高糖食品的摄入。'
      }
    ],

  },
  onLoad: function () {
    // 页面加载逻辑
  },
  go(e) {
    let {
      currentTarget: {
        dataset: {
          id
        }
      }
    } = e
    console.log(e);
    wx.pageScrollTo({
      selector: id,
      duration: 500
    })
  }
});