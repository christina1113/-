Page({
  data: {
    username: '',
    password: ''
  },
  handleLogin() {
    const { username, password } = this.data;
    if (username && password) {
      // 模拟登录成功
      wx.showToast({
        title: '登录成功',
        icon: 'success'
      });
      wx.navigateTo({
        url: '/pages/index/index'
      });
    } else {
      wx.showToast({
        title: '请输入用户名和密码',
        icon: 'none'
      });
    }
  },
  bindUsernameInput(e) {
    this.setData({
      username: e.detail.value
    });
  },
  bindPasswordInput(e) {
    this.setData({
      password: e.detail.value
    });
  }
});