// app.js
App({
  globalData: {
    openid: null,
    isLogin: false
  },
  onLaunch: function () {
    if (!wx.cloud) {
      console.error("请使用 2.2.3 或以上的基础库以使用云能力");
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        env: "cloud1-3gpg8pce421b20fa",
        traceUser: true,
      });
    }

    this.globalData = {};
    // wx.cloud.callFunction({
    //   name: 'getid', // 调用封装好的云函数
    //   success: res => {
    //     this.globalData.openid = res.result.openid
    //     console.log(this.globalData.openid);
    //     // if (res.result.code === 0) {
    //     //   console.log('获取 openid 成功，值为：', res)
    //     //   // 可以将 openid 存储在全局变量中，方便后续使用
    //     //   this.globalData.openid = res.result.data.openid
    //     // } else {
    //     //   console.error('获取 openid 失败', res.result.message)
    //     // }
    //   },
    //   fail: err => {
    //     console.error('调用云函数失败', err)
    //   }
    // })

  },
  onShow: function () {
    // 有openid意味着登录
    const openid = wx.getStorageSync('openid')
    this.globalData.openid = openid
    this.globalData.isLogin = openid ? true : false
    console.log(this.globalData.openid,this.globalData.isLogin);

  }
});